SELECT c.cnumber, c.cname
FROM courses c
JOIN departments d on c.department_code = d.dcode
WHERE dname = "Computer Science"
ORDER BY c.cnumber;
