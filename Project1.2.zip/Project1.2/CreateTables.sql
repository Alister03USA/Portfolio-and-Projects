CREATE DATABASE university;


CREATE TABLE students(
    ssn INT PRIMARY KEY,
    sid INT UNIQUE,
    name VARCHAR(20),
    gender CHAR(1),
    dob VARCHAR(10),
    c_addr VARCHAR(20),
    c_phone VARCHAR(20),
    p_addr VARCHAR(20),
    p_phone VARCHAR(20)    
);


CREATE TABLE departments(
    dcode INT PRIMARY KEY,
    dname VARCHAR(50) UNIQUE,
    phone VARCHAR(10),
    college VARCHAR(20)
);

CREATE TABLE degrees(
    dgname VARCHAR(50),
    level VARCHAR(5),
    department_code INT,
    PRIMARY KEY(dgname, level),
    FOREIGN KEY (department_code) REFERENCES departments(dcode)
);



CREATE TABLE courses(
    cnumber INT PRIMARY KEY,  
    cname VARCHAR(50),
    description VARCHAR(50),
    credithours INT,  
    level VARCHAR(20),
    department_code INT,
    FOREIGN KEY (department_code) REFERENCES departments(dcode)
);

CREATE TABLE major(
    sid INT,
    name VARCHAR(50),
    level VARCHAR(5),
    PRIMARY KEY (sid, name, level),
    FOREIGN KEY (sid) REFERENCES students(sid),
    FOREIGN KEY (name, level) REFERENCES degrees(dgname, level)
);

CREATE TABLE minor(
    sid INT,
    name VARCHAR(50),
    level VARCHAR(5),
    PRIMARY KEY (sid, name, level),
    FOREIGN KEY (sid) REFERENCES students(sid),
    FOREIGN KEY (name, level) REFERENCES degrees(dgname, level)
);

CREATE TABLE register(
    sid INT,
    course_number INT,
    regtime VARCHAR(20), 
    grade INT,
    PRIMARY KEY (sid, course_number),
    FOREIGN KEY (sid) REFERENCES students(sid),
    FOREIGN KEY (course_number) REFERENCES courses(cnumber)
);

