SELECT m.name, m.level
FROM major m
JOIN students s on s.sid = m.sid
WHERE s.name = "Julie";