SELECT c.cnumber, c.cname, COUNT(r.sid)
FROM courses c
LEFT OUTER JOIN register r on c.cnumber = r.course_number
GROUP BY c.cnumber, c.cname
ORDER BY c.cnumber;