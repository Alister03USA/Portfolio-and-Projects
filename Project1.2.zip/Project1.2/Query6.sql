SELECT s.sid, s.name
FROM students s
JOIN minor m on s.sid = m.sid
ORDER BY s.sid;