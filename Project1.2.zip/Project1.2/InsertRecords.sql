SET GLOBAL local_infile=1;


LOAD DATA LOCAL INFILE '"C:\\Users\\alist\\Downloads\\project1_data\\students.csv"'
INTO TABLE students
FIELDS TERMINATED BY ','
ENCLOSED BY '"'
LINES TERMINATED BY '\r\n'
IGNORE 1 ROWS
(sid,ssn,@col3,@col4, @col5,@col6,@col7,@col7,@col8,@col9);