SELECT s.name
FROM students s
JOIN register r on s.sid = r.sid
WHERE r.regtime = "FALL2022";
