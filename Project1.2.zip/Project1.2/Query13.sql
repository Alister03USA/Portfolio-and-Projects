SELECT d.dgname as degree_name, d.level as degree_level, COUNT(m.sid) + COUNT(mi.sid) as student_count
FROM degrees d
LEFT JOIN major m ON d.dgname = m.name AND d.level = m.level
LEFT JOIN minor mi ON d.dgname = mi.name AND d.level = mi.level
GROUP BY d.dgname, d.level
HAVING COUNT(m.sid) + COUNT(mi.sid) = (
    SELECT MAX(student_count)
    FROM (
        SELECT COUNT(m.sid) + COUNT(mi.sid) AS student_count
        FROM degrees d
        LEFT JOIN major m ON d.dgname = m.name AND d.level = m.level
        LEFT JOIN minor mi ON d.dgname = mi.name AND d.level = mi.level
        GROUP BY d.dgname, d.level
    ) AS counts
)
ORDER BY d.dgname;
