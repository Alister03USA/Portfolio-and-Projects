SELECT c_addr
FROM students
WHERE name = "Gail";