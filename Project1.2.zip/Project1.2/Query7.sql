SELECT s.sid, s.name
FROM students s
JOIN major m ON s.sid = m.sid
JOIN register r ON s.sid = r.sid
JOIN courses c ON r.course_number = c.cnumber
WHERE c.cname = 'Database' 
AND (m.level = 'MS' OR m.level = 'PhD')
ORDER BY s.sid;