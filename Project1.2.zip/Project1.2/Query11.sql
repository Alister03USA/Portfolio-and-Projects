SELECT COUNT(DISTINCT s.sid) as female_std_count
FROM students s
LEFT OUTER JOIN major ma on s.sid = ma.sid
LEFT OUTER JOIN minor mi on s.sid = mi.sid
WHERE (s.gender = 'F' or s.gender = 'f') 
AND (ma.name = 'Software Engineering' OR mi.name = 'Software Engineering');