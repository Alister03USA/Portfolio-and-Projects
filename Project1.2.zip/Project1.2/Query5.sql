SELECT d.dgname, d.level
FROM degrees d
JOIN departments dpt on dpt.dcode = d.department_code
WHERE dpt.dname = "Computer Science"
ORDER BY d.level;

