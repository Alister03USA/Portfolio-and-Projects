SELECT ma.name as degree_name, ma.level as degree_level, COUNT(ma.sid) as student_count
FROM major ma
GROUP BY ma.name, ma.level
HAVING COUNT(ma.sid) = (
    SELECT MAX(student_count)
    FROM (SELECT COUNT(sid) AS student_count FROM major GROUP BY name, level) AS counts
)
ORDER BY ma.name;
