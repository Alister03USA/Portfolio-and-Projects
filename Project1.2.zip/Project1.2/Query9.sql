SELECT name, sid, ssn
FROM students
WHERE name LIKE 'Amy' AND 'Gail'
ORDER BY name;